(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["HtmlToFigmaExtension"] = factory();
	else
		root["HtmlToFigmaExtension"] = factory();
})(self, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 117);
/******/ })
/************************************************************************/
/******/ ({

/***/ 117:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
// 全局作用域定义 processedImageIds 和 processedElements
var processedImageIds = new Set();
var processedElements = new Set();
var processedTextNodes = new Set(); // 新增：用于记录已处理的文本节点
var FONT_MAPPING = {
    'PingFangSC-Regular': 'PingFang SC',
    'FZLanTingHeiS-DB-GB': 'FZLanTingHeiS',
    'Microsoft YaHei': 'Microsoft YaHei UI'
};
var FONT_WEIGHT_MAPPING = {
    'bold': 700,
    'normal': 400,
    'lighter': 300
};
function generateUUID() {
    return Math.random().toString(36).slice(2, 11);
}
// 新增获取元素 DOM 路径的函数
function getElementPath(element) {
    var path = [];
    var currentElement = element;
    while (currentElement && currentElement !== document.documentElement) {
        var index = 0;
        var sibling = currentElement.previousElementSibling;
        while (sibling) {
            index++;
            sibling = sibling.previousElementSibling;
        }
        path.unshift("".concat(currentElement.tagName.toLowerCase(), ":nth-child(").concat(index + 1, ")"));
        currentElement = currentElement.parentElement;
    }
    return path.join(' > ');
}
function getBase64Image(img) {
    if (!img.complete || img.naturalWidth === 0)
        return '';
    var canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    var ctx = canvas.getContext('2d');
    if (!ctx)
        return '';
    try {
        ctx.drawImage(img, 0, 0);
        return canvas.toDataURL();
    }
    catch (e) {
        return ''; // 跨域图片无法转换
    }
}
// 修改获取背景图片 URL 的函数，兼容 background 属性
function getBackgroundImageUrl(style) {
    var urlRegex = /url\(['"]?([^'")]+)['"]?\)/;
    // 先尝试从 background-image 属性获取
    var backgroundImage = style.backgroundImage;
    if (backgroundImage && backgroundImage !== 'none') {
        var match = backgroundImage.match(urlRegex);
        if (match) {
            return match[1];
        }
    }
    // 若 background-image 未获取到，再尝试从 background 属性获取
    backgroundImage = style.background;
    if (backgroundImage) {
        var match = backgroundImage.match(urlRegex);
        if (match) {
            return match[1];
        }
    }
    return null;
}
// 将相对路径转换为绝对路径
function getAbsoluteUrl(relativeUrl) {
    // 新增：判断是否为 Base64 格式，若是则直接返回
    if (relativeUrl.startsWith('data:')) {
        console.log({ relativeUrl: relativeUrl });
        return relativeUrl;
    }
    var baseUrl = window.location.origin;
    if (relativeUrl.startsWith('//')) {
        return "".concat(window.location.protocol).concat(relativeUrl);
    }
    else if (relativeUrl.startsWith('/')) {
        return "".concat(baseUrl).concat(relativeUrl);
    }
    else if (!relativeUrl.startsWith('http')) {
        var currentPath = window.location.pathname;
        var lastSlashIndex = currentPath.lastIndexOf('/');
        var basePath = currentPath.slice(0, lastSlashIndex + 1);
        return "".concat(baseUrl).concat(basePath).concat(relativeUrl);
    }
    return relativeUrl;
}
// 修改元素可见性判断函数
function isElementVisible(element) {
    var style = window.getComputedStyle(element);
    var rect = element.getBoundingClientRect();
    // 检查元素是否有宽高，且不是隐藏状态
    var isVisible = style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        parseFloat(style.opacity) > 0 &&
        (rect.width > 0 || rect.height > 0);
    // 检查父元素是否可见
    var parent = element.parentElement;
    while (parent) {
        var parentStyle = window.getComputedStyle(parent);
        if (parentStyle.display === 'none' || parentStyle.visibility === 'hidden' || parseFloat(parentStyle.opacity) <= 0) {
            return false;
        }
        parent = parent.parentElement;
    }
    return isVisible;
}
function getLayoutMode(element) {
    var style = window.getComputedStyle(element);
    return style.display === 'flex' && style.flexDirection === 'column'
        ? 'VERTICAL'
        : style.display === 'flex'
            ? 'HORIZONTAL'
            : 'NONE';
}
function parseColor(colorStr) {
    if (colorStr === 'transparent')
        return { r: 0, g: 0, b: 0, a: 0 };
    var rgba = colorStr.match(/\d+\.?\d*/g) || ['0', '0', '0', '1'];
    return {
        r: parseFloat(rgba[0]) / 255,
        g: parseFloat(rgba[1]) / 255,
        b: parseFloat(rgba[2]) / 255,
        a: rgba[3] ? parseFloat(rgba[3]) : 1
    };
}
// 定义类型守卫函数
function isNodeType(value) {
    return value !== null;
}
var sanitize = function (num) { return Math.round(num); };
// 将 convertElement 函数改为异步函数
function convertElement(element) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function () {
        var elementPath, rect, style, baseNode, isLocalImage, imageUrl, uniqueId, imageId, backgroundImageUrl, absoluteUrl, isLocalImage, imageUrl, img_1, uniqueId, imageId, processTextNodes, childrenPromises, children;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    elementPath = getElementPath(element);
                    if (processedElements.has(elementPath)) {
                        return [2 /*return*/, null];
                    }
                    processedElements.add(elementPath);
                    if (!element.isConnected) {
                        return [2 /*return*/, null];
                    }
                    rect = element.getBoundingClientRect();
                    style = window.getComputedStyle(element);
                    baseNode = {
                        id: element.id || "auto-".concat(generateUUID()),
                        name: element.tagName.toLowerCase(),
                        type: 'FRAME',
                        visible: isElementVisible(element),
                        absoluteBoundingBox: {
                            x: sanitize(rect.left),
                            y: sanitize(rect.top),
                            width: sanitize(rect.width),
                            height: sanitize(rect.height)
                        },
                        constraints: {
                            horizontal: 'SCALE',
                            vertical: 'SCALE'
                        },
                        fills: style.backgroundColor !== 'rgba(0, 0, 0, 0)' ? [{
                                type: 'SOLID',
                                color: parseColor(style.backgroundColor),
                                opacity: parseFloat(style.opacity)
                            }] : [],
                        children: []
                    };
                    // 处理 HTMLImageElement
                    if (element instanceof HTMLImageElement && element.naturalWidth > 0) {
                        isLocalImage = !/^(https?:)?\/\//.test(element.src);
                        imageUrl = isLocalImage ? getBase64Image(element) : element.src;
                        uniqueId = ((_a = element.src.split('/').pop()) === null || _a === void 0 ? void 0 : _a.split('?')[0]) || generateUUID();
                        imageId = "".concat(element.id || "img-".concat(uniqueId), "-").concat(elementPath);
                        if (processedImageIds.has(imageId)) {
                            return [2 /*return*/, baseNode];
                        }
                        processedImageIds.add(imageId);
                        return [2 /*return*/, __assign(__assign({}, baseNode), { id: imageId, type: 'IMAGE', name: 'image', absoluteBoundingBox: __assign(__assign({}, baseNode.absoluteBoundingBox), { width: element.naturalWidth, height: element.naturalHeight }), fills: [{
                                        url: imageUrl,
                                        type: 'IMAGE',
                                        scaleMode: 'FILL',
                                        width: element.naturalWidth,
                                        height: element.naturalHeight,
                                        imageDesc: element.alt || "image-".concat(generateUUID())
                                    }] })];
                    }
                    backgroundImageUrl = getBackgroundImageUrl(style);
                    if (!backgroundImageUrl) return [3 /*break*/, 4];
                    absoluteUrl = getAbsoluteUrl(backgroundImageUrl);
                    isLocalImage = !/^(https?:)?\/\//.test(absoluteUrl);
                    imageUrl = absoluteUrl;
                    if (!isLocalImage) return [3 /*break*/, 3];
                    img_1 = new Image();
                    img_1.src = absoluteUrl;
                    if (!!img_1.complete) return [3 /*break*/, 2];
                    return [4 /*yield*/, new Promise(function (resolve) {
                            img_1.onload = resolve;
                            img_1.onerror = resolve;
                        })];
                case 1:
                    _c.sent();
                    _c.label = 2;
                case 2:
                    imageUrl = getBase64Image(img_1);
                    console.log({ imageUrl: imageUrl });
                    _c.label = 3;
                case 3:
                    uniqueId = ((_b = absoluteUrl.split('/').pop()) === null || _b === void 0 ? void 0 : _b.split('?')[0]) || generateUUID();
                    imageId = "bg-img-".concat(uniqueId, "-").concat(elementPath);
                    if (processedImageIds.has(imageId)) {
                        return [2 /*return*/, baseNode];
                    }
                    processedImageIds.add(imageId);
                    return [2 /*return*/, __assign(__assign({}, baseNode), { id: imageId, type: 'IMAGE', name: 'background-image', absoluteBoundingBox: __assign(__assign({}, baseNode.absoluteBoundingBox), { width: sanitize(rect.width), height: sanitize(rect.height) }), fills: [{
                                    url: imageUrl,
                                    type: 'IMAGE',
                                    scaleMode: 'FILL',
                                    width: sanitize(rect.width),
                                    height: sanitize(rect.height),
                                    imageDesc: "background-image-".concat(generateUUID())
                                }] })];
                case 4:
                    processTextNodes = function (node) {
                        var _a;
                        if (node.nodeType === Node.TEXT_NODE) {
                            var textNode = node;
                            if (processedTextNodes.has(textNode)) {
                                return;
                            }
                            processedTextNodes.add(textNode);
                            var characters = (_a = textNode.textContent) === null || _a === void 0 ? void 0 : _a.trim();
                            if (characters) {
                                var style_1 = window.getComputedStyle(element);
                                var fontFamily = style_1.fontFamily.replace(/["']/g, '')
                                    .split(',')[0]
                                    .trim()
                                    .replace(/(SC|GB)/g, ' ').trim();
                                var textNodeObj = __assign(__assign({}, baseNode), { id: "".concat(baseNode.id, "-text-").concat(generateUUID()), type: 'TEXT', characters: characters, style: {
                                        fontFamily: FONT_MAPPING[fontFamily] || fontFamily,
                                        fontWeight: FONT_WEIGHT_MAPPING[style_1.fontWeight] || 400,
                                        fontSize: sanitize(parseFloat(style_1.fontSize)),
                                        lineHeight: {
                                            unit: 'PIXELS',
                                            value: parseFloat(style_1.lineHeight) || sanitize(parseFloat(style_1.fontSize) * 1.2)
                                        }
                                    }, fills: [{
                                            type: 'SOLID',
                                            color: parseColor(style_1.color),
                                            opacity: 1
                                        }], children: [] });
                                baseNode.children.push(textNodeObj);
                            }
                        }
                        else if (node.nodeType === Node.ELEMENT_NODE) {
                            var childElement = node;
                            childElement.childNodes.forEach(processTextNodes);
                        }
                    };
                    element.childNodes.forEach(processTextNodes);
                    if (baseNode.children.length > 0) {
                        return [2 /*return*/, baseNode];
                    }
                    if (!(element.children.length > 0)) return [3 /*break*/, 6];
                    childrenPromises = Array.from(element.children).map(convertElement);
                    return [4 /*yield*/, Promise.all(childrenPromises)];
                case 5:
                    children = _c.sent();
                    return [2 /*return*/, __assign(__assign({}, baseNode), { type: 'FRAME', layoutMode: getLayoutMode(element), itemSpacing: sanitize(parseFloat(style.gap)), children: children.filter(isNodeType) })];
                case 6: return [2 /*return*/, baseNode];
            }
        });
    });
}
// 修改顶层过滤逻辑，使用 async 包裹
(function () { return __awaiter(void 0, void 0, void 0, function () {
    var filteredElements, convertPromises, convertedElements, figmaDoc, blob, link_1, pageTitle, timestamp, error_1;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                filteredElements = Array.from(document.querySelectorAll('*')).filter(function (node) {
                    var _a;
                    var tag = node.tagName;
                    var isHidden = node.hasAttribute('hidden') || node.getAttribute('aria-hidden') === 'true';
                    var isValidTag = !['SCRIPT', 'STYLE', 'META', 'LINK', 'SVG'].includes(tag);
                    var style = window.getComputedStyle(node);
                    var isVisible = style.display !== 'none' &&
                        style.visibility !== 'hidden' &&
                        parseFloat(style.opacity) > 0 &&
                        (node.getClientRects().length > 0);
                    // 检查节点自身或其子节点是否有文本内容
                    var hasTextContent = ((_a = node.textContent) === null || _a === void 0 ? void 0 : _a.trim()) || Array.from(node.childNodes).some(function (child) { var _a; return (_a = child.textContent) === null || _a === void 0 ? void 0 : _a.trim(); });
                    return isValidTag && isVisible && !isHidden && hasTextContent;
                });
                convertPromises = filteredElements.map(convertElement);
                return [4 /*yield*/, Promise.all(convertPromises)];
            case 1:
                convertedElements = _a.sent();
                figmaDoc = {
                    document: {
                        type: "DOCUMENT",
                        id: "root",
                        name: "Converted Page",
                        children: convertedElements.filter(isNodeType)
                    },
                    schemaVersion: 0
                };
                blob = new Blob([JSON.stringify(figmaDoc, null, 2)], {
                    type: "application/json"
                });
                link_1 = document.createElement("a");
                link_1.href = URL.createObjectURL(blob);
                pageTitle = document.title.replace(/[\\/:"*?<>|]/g, '_');
                timestamp = Date.now();
                link_1.download = "".concat(pageTitle, "-").concat(timestamp, ".json");
                document.body.appendChild(link_1);
                link_1.click();
                setTimeout(function () { return link_1.remove(); }, 100);
                return [3 /*break*/, 3];
            case 2:
                error_1 = _a.sent();
                console.error('[Figma导出] 失败:', error_1);
                if (error_1 instanceof Error) {
                    alert("\u5BFC\u51FA\u5931\u8D25: ".concat(error_1.message));
                }
                else {
                    alert('发生未知错误');
                }
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); })();


/***/ })

/******/ });
});